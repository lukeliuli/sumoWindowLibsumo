---
title: Z/Changes from Version 0.12.1 to Version 0.12.2
permalink: /Z/Changes_from_Version_0.12.1_to_Version_0.12.2/
---

**Release Date: 7.12.2010**

- all
  - added options to save the xml schema for the configuration file
  - added "--version" option
- Simulation
  - arrivalpos, arrivallane and arrivalspeed parameters for vehicles
  - correcting lots of person handling bugs
  - refactoring vehicle route output and tripinfo into devices
  - clean up of inheritance structure of MSVehicle
- GUI
  - drawing arrows instead of using bitmaps