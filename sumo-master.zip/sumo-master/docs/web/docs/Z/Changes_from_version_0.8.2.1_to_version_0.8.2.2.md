---
title: Z/Changes from version 0.8.2.1 to version 0.8.2.2
permalink: /Z/Changes_from_version_0.8.2.1_to_version_0.8.2.2/
---

User-relevant changes:

- Simulation
  - XML-Trigger bug on using speed triggers removed
  - emission of vehicles on multi-lane source edges debugged (now all lanes are used)
  - Debugged the problem of vehicles stopping before the route is over (reported by Jonathan Davies)
  - setting tls-offsets debugged
- Netconvert
  - Computation of left-movers debugged