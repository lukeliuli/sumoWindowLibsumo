---
title: Z/Changes from Version 0.17.0 to Version 0.17.1
permalink: /Z/Changes_from_Version_0.17.0_to_Version_0.17.1/
---

## Version 0.17.1 (08.05.2013)

### Bugfixes

- SUMO-GUI
  - fixed crash when opening the viewport-dialog
- NETCONVERT
  - fixed wrong permissions when writing output in the dlr-navteq format