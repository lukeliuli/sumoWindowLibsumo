---
title: Z/Changes from version 0.7.0 to version pre0.8
permalink: /Z/Changes_from_version_0.7.0_to_version_pre0.8/
---

- Further applications added: router, od2trips-converter, tagreader
- A graphical user interface
- Further import possibilities added: ArcView, Visum, Vissim (partly in work), ARTEMIS
- A new concept of the microsimulation
- Traffic lights simulation
- Working lane changing