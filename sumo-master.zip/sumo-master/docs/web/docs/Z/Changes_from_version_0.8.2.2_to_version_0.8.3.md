---
title: Z/Changes from version 0.8.2.2 to version 0.8.3
permalink: /Z/Changes_from_version_0.8.2.2_to_version_0.8.3/
---

User-relevant changes

- Simulation
  - debugged false tls-offset computation
- Windows-package
  - added libraries missing in 0.8.2.2