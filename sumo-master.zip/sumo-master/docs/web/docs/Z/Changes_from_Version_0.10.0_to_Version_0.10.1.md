---
title: Z/Changes from Version 0.10.0 to Version 0.10.1
permalink: /Z/Changes_from_Version_0.10.0_to_Version_0.10.1/
---

- GUISIM
  - debugged right-click on an empty cell

- Simulation
  - removed bug in collision detection
  - added warning about old route format