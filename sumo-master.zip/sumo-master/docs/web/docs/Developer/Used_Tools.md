---
title: Developer/Used Tools
permalink: /Developer/Used_Tools/
---

- [TextTest](http://texttest.sourceforge.net/) An acceptance test framework.
- [UMLet](http://www.umlet.com/) Free UML diagrams drawing tool.
- [Doxygen](http://www.doxygen.nl/) A class
  documentation utility.
- [gtest (googletest)](http://code.google.com/p/googletest/) A
  unit-test framework.