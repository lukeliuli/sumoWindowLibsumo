---
title: Networks/Import/RoboCup
permalink: /Networks/Import/RoboCup/
---

This import function is in a rather experimental state. We need someone
who owns a network she/he knows and who could give us an advice whether
the import work as expected. You still may try it out using the option **--robocup-net** {{DT_FILE}}
(or shorter: **--robocup** {{DT_FILE}}).