---
title: Tutorials/Open and Simulate
permalink: /Tutorials/Open_and_Simulate/
---

# Things to know first

## What is a scenario?

# Open a scenario