---
title: Purgatory/NETCONVERT TlsComputation
permalink: /Purgatory/NETCONVERT_TlsComputation/
---

- using always a pair is not proper in some cases; similar directions
  should be joined
- left-movers are not computed properly (not recognized as such) for
  joined-TLSs
- two incoming/two outgoing: what to do, here?
- if only one major street is incoming, it is not used as such within
  the best match combination computation