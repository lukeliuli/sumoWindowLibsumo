---
title: Purgatory/Simulation Performance
permalink: /Purgatory/Simulation_Performance/
---

One of the followed design goals was to achieve a high simulation speed.
A simulation can not be fast enough, and below you may find some notes
on how the speed can be increased.

# Command Line Output & TraCI

- plain execution with TraCI: 24 min
- no TraCI: about 7 min
- Disabling reporting partially: 1:44 min
- Disabling reporting completely: 50 sec