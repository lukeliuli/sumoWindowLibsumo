---
title: Purgatory/TraCI/Command-Comparison
permalink: /Purgatory/TraCI/Command-Comparison/
---

| Domain / sources | command                        | subcommand                           | parameters | old TraCI equivalent |
| ---------------- | ------------------------------ | ------------------------------------ | ---------- | -------------------- |
| Simulation       | CMD_GET_SIM_VARIABLE = 0xab | VAR_TIME_STEP = 0x70               | none       | \-                   |
|                  |                                | VAR_LOADED_VEHICLES_NUMBER = 0x71 | none       | \-                   |